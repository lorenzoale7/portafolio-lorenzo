# Portafolio digital — Mi recorrido hacia el futuro

Sitio estático para publicar con GitHub Pages.

## Estructura
- `index.html`: Inicio / Sobre mí.
- `educacion-financiera.html`: Experiencia 1 y su imagen.
- `unsam.html`: Experiencia 2 y su imagen.
- `uca.html`: Experiencia 3 y su imagen.
- `uba.html`: Experiencia 4 y su imagen.
- `curso-ia.html`: Experiencia 5 y su imagen.
- `banco-ciudad.html`: Experiencia 6 y su imagen.
- `assets/`: imágenes de evidencia.

Subí todos estos archivos y la carpeta `assets` a la raíz del repositorio de GitHub.
